//Pacote que esse codigo esta organizado
package meuapp;

import java.util.Scanner;
//Declaracao da classe L1QA

public class L1QA {

    //Metodo principal
    public static void main(String[] args) {
        int idade = 0;
        System.out.println("Digite sua idade");
        //idade = new Scanner(System.in).nextInt();
        idade = Integer.parseInt(new Scanner(System.in).nextLine());
        
        if(idade < 18){
            System.out.println("Infelizmente você não tem idade para dirigir");
        }else {
            System.out.println("Parabéns você tem idade para dirigir");
        }
        
    }

}
