
package ujcar;

import static java.lang.Boolean.*;

public class UJCar {

    // Type cast
    static void mostraoveiculo(Veiculo v){
        v.mostraTudo();
    }
    
    //Método principal do game
    public static void main(String[] args) {
       
       //Instancia (cria) e 
       Carro carro_da_clara = new Carro("Rosa","Ferrari",new Motor(620), new Freio(0.15), new Turbo());
       
       Motor motorvpower = new Motor(650);
       Freio freioabspower = new Freio(0.25);
       Carro carro_do_bernardo = new Carro("Amarelo","Lamborghini", motorvpower, freioabspower, new Turbo());
       carro_do_bernardo.acelerar(FALSE);
       carro_do_bernardo.acelerar(TRUE);
       mostraoveiculo(carro_do_bernardo);
       carro_do_bernardo.acelerar(FALSE);
       carro_do_bernardo.acelerar(TRUE);
       mostraoveiculo(carro_do_bernardo);
       
       //Criando uma moto
       Moto moto_do_pedro = new Moto("Preta", "Harley-Davidson", new Motor(1000), new Freio(0.25));
       
       mostraoveiculo(moto_do_pedro);
       moto_do_pedro.acelerar();
       moto_do_pedro.acelerar();
       mostraoveiculo(moto_do_pedro);
       
    }
    
}
