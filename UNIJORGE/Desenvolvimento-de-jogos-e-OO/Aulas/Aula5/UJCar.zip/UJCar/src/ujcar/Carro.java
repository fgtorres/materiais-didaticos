package ujcar;

public class Carro  extends Veiculo {
    
    private Turbo turbo;
    
    //Método que acelera o carro
    void acelerar(Boolean usarturbo){
        if(usarturbo){
            super.setVelocidade(getVelocidade() + this.turbo.turbinar(super.getMotor().aceleracao()));
        }else{
            super.setVelocidade(super.getVelocidade() + super.getMotor().aceleracao());
        }
    }
    
    //Método que freia o carro
    void frear(){
        super.setVelocidade(super.getFreio().desaceleracao(super.getVelocidade()));
    }    
    
    //Método construtor de objetos
    Carro(String cor, String marca, Motor motor, Freio freio, Turbo turbo){
        super.setCor(cor);
        super.setMarca(marca);
        super.setMotor(motor);
        super.setFreio(freio);
        this.turbo = turbo;
    }

    public Turbo getTurbo() {
        return turbo;
    }

    public void setTurbo(Turbo turbo) {
        this.turbo = turbo;
    }
    
    
}
