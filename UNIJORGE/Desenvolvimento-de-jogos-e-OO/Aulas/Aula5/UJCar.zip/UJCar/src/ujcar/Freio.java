
package ujcar;

public class Freio {
   
    private Double resistencia;
    
    //Construtor
    Freio(Double resistencia){
        setResistencia(resistencia);
    }

    int desaceleracao(int velocidade){
        //Checando se o carro parou
        return (int)((velocidade < 10) ?  velocidade : Math.round(velocidade * this.resistencia));
    }
    
    // Gets e sets 
    Double getResistencia(){
        return this.resistencia;
    }
    
    void setResistencia(Double resistencia){
        if(resistencia > 1){
            System.out.println("Cara nao da pra ser maior que um ne nao?");
        }else{
            this.resistencia = resistencia;
        } 
    }
}
