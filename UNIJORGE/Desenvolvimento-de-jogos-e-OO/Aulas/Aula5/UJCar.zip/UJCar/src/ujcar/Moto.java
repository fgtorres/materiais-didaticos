
package ujcar;

public class Moto extends Veiculo {
    
    //Método que acelera o moto
    void acelerar(){
        super.setVelocidade(super.getVelocidade() + super.getMotor().aceleracao());
    }

    //Método que freia o moto
    void frear(){
        super.setVelocidade(super.getFreio().desaceleracao(super.getVelocidade()));
    }    
    
    //Método construtor de objetos
    Moto(String cor, String marca, Motor motor, Freio freio){
        super.setCor(cor);
        super.setMarca(marca);
        super.setMotor(motor);
        super.setFreio(freio);
    }
    
}
