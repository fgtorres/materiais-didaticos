package ujcar;

public class Motor {
 
    private int potencia;
    
    //Construtor do motor
    Motor(int potencia){
        this.potencia = potencia;
    }
    
    int aceleracao(){
        return Math.round(potencia/10);
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }
    
    
    
}
