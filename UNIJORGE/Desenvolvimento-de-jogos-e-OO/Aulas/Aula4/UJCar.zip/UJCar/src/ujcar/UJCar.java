
package ujcar;

public class UJCar {

    //Método principal do game
    public static void main(String[] args) {
       
       //Instancia (cria) e 
       Carro carro_da_clara = new Carro("Rosa","Ferrari",new Motor(620), new Freio(0.15));
       
       Motor motorvpower = new Motor(650);
       Freio freioabspower = new Freio(0.25);
       Carro carro_do_bernardo = new Carro("Amarelo","Lamborghini", motorvpower, freioabspower);
       
       System.out.println(carro_da_clara.freio.getResistencia());
       carro_da_clara.freio.setResistencia(2.25);
       System.out.println(carro_da_clara.freio.getResistencia());
       
       
       
    }
    
}
