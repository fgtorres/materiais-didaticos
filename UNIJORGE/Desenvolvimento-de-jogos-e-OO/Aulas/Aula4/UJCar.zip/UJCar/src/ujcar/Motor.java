package ujcar;

public class Motor {
 
    int potencia;
    
    //Construtor do motor
    Motor(int potencia){
        this.potencia = potencia;
    }
    
    int aceleracao(){
        return Math.round(potencia/10);
    }
    
}
