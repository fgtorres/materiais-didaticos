package ujcar;

public class Carro {
    //Atributos da classe
    String cor = "";
    String marca = "";
    Integer velocidade = 0;
    
    //Associação em OO
    Motor motor;
    Freio freio;
    
    //Método que acelera o carro
    void acelerar(){
        this.velocidade += this.motor.aceleracao();
    }
    
    //Método que para o carro
    void parar(){
        //Utilizamos o this para referenciar a variável do objeto e não o parâmetro.
        this.velocidade = 0;
    }
    
    //Método que freia o carro
    void frear(){
        this.velocidade -= this.freio.desaceleracao(this.velocidade);
    }    
    
    //Método que printa no console os atributos do objeto.
    void mostraTudo(){
       //Printa no console a cor armazenada no objeto.
       System.out.println(this.cor);
       System.out.println(this.marca);
       System.out.println(this.velocidade);
    }
    
    //Método construtor de objetos
    Carro(String cor, String marca, Motor motor, Freio freio){
        this.cor = cor;
        this.marca = marca;
        this.motor = motor;
        this.freio = freio;
    }
}
