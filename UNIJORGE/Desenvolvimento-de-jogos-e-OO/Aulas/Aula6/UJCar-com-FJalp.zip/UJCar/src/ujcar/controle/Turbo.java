
package ujcar.controle;

public class Turbo {
    
    int turbinar(int aceleracao){
        return aceleracao*10;
    }
    
}
