


public class Componente {
    
    void imprimir(){
        
    }
    
}
