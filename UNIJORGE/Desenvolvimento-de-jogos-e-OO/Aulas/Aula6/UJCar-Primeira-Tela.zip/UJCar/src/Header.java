public class Header extends Componente{
    
    //Sobreescrita
    void imprimir(){
        Fjalp2.getTerminal().setCor(CorFonte.VERDE, CorFundo.PRETO);
        Fjalp2.getTerminal().escrevaln(" .----------------.  .----------------.   .----------------.  .----------------.  .----------------."); 
        Fjalp2.getTerminal().escrevaln("| .--------------. || .--------------. | | .--------------. || .--------------. || .--------------. |");
        Fjalp2.getTerminal().escreva("| | ");
        Fjalp2.getTerminal().setCor(CorFonte.VERMELHO, CorFundo.PRETO);
        Fjalp2.getTerminal().escreva("_____  _____");
        Fjalp2.getTerminal().setCor(CorFonte.VERDE, CorFundo.PRETO);
        Fjalp2.getTerminal().escrevaln(" | || |     _____    | | | |     ______   | || |      __      | || |  _______     | |");
        Fjalp2.getTerminal().escreva("| |");
        Fjalp2.getTerminal().setCor(CorFonte.VERMELHO, CorFundo.PRETO);
        Fjalp2.getTerminal().escreva("|");
        Fjalp2.getTerminal().setCor(CorFonte.VERMELHO, CorFundo.VERMELHO);
        Fjalp2.getTerminal().escreva("_   _");
        Fjalp2.getTerminal().setCor(CorFonte.VERMELHO, CorFundo.PRETO);
        Fjalp2.getTerminal().escreva("|");
        Fjalp2.getTerminal().escreva("|");
        Fjalp2.getTerminal().setCor(CorFonte.VERMELHO, CorFundo.VERMELHO);
        Fjalp2.getTerminal().escreva("_   _");
        Fjalp2.getTerminal().setCor(CorFonte.VERMELHO, CorFundo.PRETO);
        Fjalp2.getTerminal().escreva("|");
        Fjalp2.getTerminal().setCor(CorFonte.VERDE, CorFundo.PRETO);
        Fjalp2.getTerminal().escrevaln("| || |    |_   _|   | | | |   .' ___  |  | || |     /  \\     | || | |_   __ \\    | |");
        Fjalp2.getTerminal().escrevaln("| |  | |    | |  | || |      | |     | | | |  / .'   \\_|  | || |    / /\\ \\    | || |   | |__) |   | |");
        Fjalp2.getTerminal().escrevaln("| |  | '    ' |  | || |   _  | |     | | | |  | |         | || |   / ____ \\   | || |   |  __ /    | |");
        Fjalp2.getTerminal().escrevaln("| |   \\ `--' /   | || |  | |_' |     | | | |  \\ `.___.'\\  | || | _/ /    \\ \\_ | || |  _| |  \\ \\_  | |");
        Fjalp2.getTerminal().escrevaln("| |    `.__.'    | || |  `.___.'     | | | |   `._____.'  | || ||____|  |____|| || | |____| |___| | |");
        Fjalp2.getTerminal().escrevaln("| |              | || |              | | | |              | || |              | || |              | |");
        Fjalp2.getTerminal().escrevaln("| '--------------' || '--------------' | | '--------------' || '--------------' || '--------------' |");
        Fjalp2.getTerminal().escrevaln(" '----------------'  '----------------'   '----------------'  '----------------'  '----------------' ");
        
    }
}
