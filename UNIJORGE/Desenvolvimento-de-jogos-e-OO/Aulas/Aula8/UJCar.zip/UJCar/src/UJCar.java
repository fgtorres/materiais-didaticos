
public class UJCar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new TelaInicial().imprimir();
    }
     
    
}
