
public class TelaInicial extends Componente implements Tela{

    @Override
    public void imprimir() {
        imprimircabecalho();
        new Header(CorFundo.PRETO,CorFonte.AZUL,CorFonte.BRANCO,4,8).imprimir();
        new Botao(CorFonte.PRETO,CorFundo.AMARELO, 5, 65, "(C)omecar").imprimir();
        new Botao(CorFonte.PRETO,CorFundo.AMARELO, 10, 65, "(S)obre").imprimir();
        
        int width = Fjalp2.getTerminal().getJlineTerminal().getTerminalWidth();
        int height = Fjalp2.getTerminal().getJlineTerminal().getTerminalHeight();
        Fjalp2.getTerminal().setCor(CorFonte.PRETO ,CorFundo.AMARELO);
        Fjalp2.getTerminal().setPosicaoCursor(height, 0);
        
        for (int i=0; i<=(width-1); i++){
            Fjalp2.getTerminal().escreva(" ");
        }
        
        Fjalp2.getTerminal().setPosicaoCursor(height-1, 0);
        Fjalp2.getTerminal().escreva("Digite a primeira letra do botao desejado: ");
        String op = Fjalp2.getTerminal().leiaString();
        
    }

    @Override
    public void imprimircabecalho() {
        new Cabecalho().imprimir();
    }

    @Override
    public void resetCursorPosition() {
        
    }
    
}
