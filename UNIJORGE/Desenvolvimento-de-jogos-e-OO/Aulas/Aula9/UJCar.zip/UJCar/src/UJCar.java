
public class UJCar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TelaInicial telainicial = new TelaInicial();
        telainicial.imprimircabecalho();
        telainicial.imprimir();   
        
    }
     
    
}
