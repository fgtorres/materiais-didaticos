package ujcar;

public class Motor {
 
    
    
}
