package ujcar;

public class Carro {
    //Atributos da classe
    String cor = "";
    String marca = "";
    Integer velocidade = 0;
    Motor motor;
    Freio freio;
    
    void acelerar(){
        this.velocidade += this.motor.aceleracao;
    }
    
    void parar(){
        this.velocidade = 0;
    }
    
    void frear(){
        this.velocidade -= this.freio.desceleracao;
    }    
    
    void mostraTudo(){
       System.out.println(this.cor);
       System.out.println(this.marca);
       System.out.println(this.velocidade);
    }
    
    //Método construtor
    Carro(String cor, String marca, Motor motor){
        this.cor = cor;
        this.marca = marca;
        this.motor = motor;
    }
}
