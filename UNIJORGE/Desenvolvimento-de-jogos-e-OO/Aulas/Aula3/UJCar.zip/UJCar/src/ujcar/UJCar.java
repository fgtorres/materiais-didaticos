
package ujcar;

public class UJCar {

    //Método principal do game
    public static void main(String[] args) {
       Carro carro_da_clara = new Carro("Rosa","Ferrari");
       Carro carro_do_bernardo = new Carro("Amarelo","Lamborghini");
       
       carro_da_clara.mostraTudo();
       carro_do_bernardo.mostraTudo();
       
       carro_da_clara.acelerar();
       carro_do_bernardo.acelerar();
       carro_da_clara.acelerar();
       
       carro_da_clara.mostraTudo();
       carro_do_bernardo.mostraTudo();
    }
    
}
