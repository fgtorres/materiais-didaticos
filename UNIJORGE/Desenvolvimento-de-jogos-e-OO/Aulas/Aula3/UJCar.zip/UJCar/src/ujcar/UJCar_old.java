
package ujcar;

public class UJCar_old {

    public static void main(String[] args) {
        //Declaramos as variáveis
        String carro = "0";
        Integer velocidade = 0;
        
        //Criei o carro
        carro = "Ferrari vermelha";
        
        //Acelerar o carro
        velocidade += 10;
        velocidade += 10;
        velocidade += 10;
        
        //Parar o carro
        velocidade -= 10;
        velocidade -= 10;
        velocidade -= 10;
        
        //Mostrei o carro
        System.out.println(carro);
        System.out.println(velocidade);
        
         //Declaramos as variáveis
        String carro2 = "";
        Integer velocidade2 = 0;
        
        //Criei o carro
        carro2 = "Ferrari vermelha";
        
        //Acelerar o carro
        velocidade2 += 10;
        velocidade2 += 10;
        velocidade2 += 10;
        
        //Parar o carro
        velocidade2 -= 10;
        velocidade2 -= 10;
        velocidade2 -= 10;
        
        //Mostrei o carro
        System.out.println(carro2);
        System.out.println(velocidade2);
        
         //Declaramos as variáveis
        String carro3 = "";
        Integer velocidade3 = 0;
        
        //Criei o carro
        carro3 = "Ferrari vermelha";
        
        //Acelerar o carro
        velocidade3 += 10;
        velocidade3 += 10;
        velocidade3 += 10;
        
        //Parar o carro
        velocidade3 -= 10;
        velocidade3 -= 10;
        velocidade3 -= 10;
        
        //Mostrei o carro
        System.out.println(carro3);
        System.out.println(velocidade3);
        
         //Declaramos as variáveis
        String carro4 = "";
        Integer velocidade4 = 0;
        
        //Criei o carro
        carro4 = "Ferrari vermelha";
        
        //Acelerar o carro
        velocidade4 += 10;
        velocidade4 += 10;
        velocidade4 += 10;
        
        //Parar o carro
        velocidade4 -= 10;
        velocidade4 -= 10;
        velocidade4 -= 10;
        
        //Mostrei o carro
        System.out.println(carro4);
        System.out.println(velocidade4);
        
         //Declaramos as variáveis
        String carro5 = "";
        Integer velocidade5 = 0;
        
        //Criei o carro
        carro5 = "Ferrari vermelha";
        
        //Acelerar o carro
        velocidade5 += 10;
        velocidade5 += 10;
        velocidade5 += 10;
        
        //Parar o carro
        velocidade5 = 0;
        
        //Mostrei o carro
        System.out.println(carro5);
        System.out.println(velocidade5);
    }
    
}
