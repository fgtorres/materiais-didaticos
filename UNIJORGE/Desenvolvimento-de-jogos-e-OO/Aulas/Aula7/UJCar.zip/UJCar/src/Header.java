public class Header extends Componente{
    private int Corsombreamento = CorFundo.PRETO;
    private int Corlinha = CorFonte.AZUL;
    private int Corfrontal = CorFonte.BRANCO;
    private int posinicialx = 10;
    private int posinicialy = 60;

    public Header(int Corsombreamento, int Corlinha, int Corfrontal, int posinicialx, int posinicialy) {
        this.Corsombreamento = Corsombreamento;
        this.Corfrontal = Corfrontal;
        this.Corlinha = Corlinha;
        this.posinicialx = posinicialx;
        this.posinicialy = posinicialy;
    }

    public Header() {
    }
    
    //Sobreescrita
    void imprimir(){
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx, posinicialy);
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+1, posinicialy);
        Fjalp2.getTerminal().escrevaln("           _____                    _____              ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+2, posinicialy);
        Fjalp2.getTerminal().escrevaln("          /\\    \\                  /\\    \\             ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+3, posinicialy);
        Fjalp2.getTerminal().escreva("         /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("\\____\\                /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("\\    \\            ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+4, posinicialy);
        Fjalp2.getTerminal().escreva("        /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /                \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("\\    \\           ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+5, posinicialy);
        Fjalp2.getTerminal().escreva("       /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /                  \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("\\    \\          ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+6, posinicialy);
        Fjalp2.getTerminal().escreva("      /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /                    \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("\\    \\         ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+7, posinicialy);
        Fjalp2.getTerminal().escreva("     /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /                      \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("\\    \\        ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+8, posinicialy);
        Fjalp2.getTerminal().escreva("    /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /                       /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("\\    \\       ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+9, posinicialy);
        Fjalp2.getTerminal().escreva("   /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /      _____    _____   /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::::::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("\\    \\      ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+10, posinicialy);
        Fjalp2.getTerminal().escreva("  /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/____/      /\\    \\  /\\    \\ /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/\\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("\\    \\     ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+11, posinicialy);
        Fjalp2.getTerminal().escreva(" /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /      /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("\\____\\/");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("\\    /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/  \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("\\____\\    ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+12, posinicialy);
        Fjalp2.getTerminal().escreva(" \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("\\____\\     /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /\\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("\\  /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("/    /    ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+13, posinicialy);
        Fjalp2.getTerminal().escreva("  \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("\\    \\   /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /  \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("\\/");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("/    / \\/____/     ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+14, posinicialy);
        Fjalp2.getTerminal().escreva("   \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("\\    \\ /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /    \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::::::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("/    /              ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+15, posinicialy);
        Fjalp2.getTerminal().escreva("    \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("\\    /");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /      \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("/    /               ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+16, posinicialy);
        Fjalp2.getTerminal().escreva("     \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("\\__/");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva(":::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escreva("/    /        \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("/    /                ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+17, posinicialy);
        Fjalp2.getTerminal().escreva("      \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::::::::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("/    /          \\/____/                 ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+18, posinicialy);
        Fjalp2.getTerminal().escreva("       \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::::::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("/    /                                   ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+19, posinicialy);
        Fjalp2.getTerminal().escreva("        \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("/    /                                    ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+20, posinicialy);
        Fjalp2.getTerminal().escreva("         \\");
        Fjalp2.getTerminal().setCor(Corfrontal, Corsombreamento);
        Fjalp2.getTerminal().escreva("::");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().escrevaln("/____/                                     ");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+21, posinicialy);
        
    }

    public int getCorsombreamento() {
        return Corsombreamento;
    }

    public void setCorsombreamento(int Corsombreamento) {
        this.Corsombreamento = Corsombreamento;
    }

    public int getCorlinha() {
        return Corlinha;
    }

    public void setCorlinha(int Corlinha) {
        this.Corlinha = Corlinha;
    }

    public int getCorfrontal() {
        return Corfrontal;
    }

    public void setCorfrontal(int Corfrontal) {
        this.Corfrontal = Corfrontal;
    }

    public int getPosinicialx() {
        return posinicialx;
    }

    public void setPosinicialx(int posinicialx) {
        this.posinicialx = posinicialx;
    }

    public int getPosinicialy() {
        return posinicialy;
    }

    public void setPosinicialy(int posinicialy) {
        this.posinicialy = posinicialy;
    }
    
    
}
