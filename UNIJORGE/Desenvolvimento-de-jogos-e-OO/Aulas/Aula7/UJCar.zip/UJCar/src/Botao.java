
public class Botao extends Componente {
    
    private int Corsombreamento = CorFundo.AMARELO;
    private int Corlinha = CorFonte.PRETO;
    private int posinicialx = 10;
    private int posinicialy = 65; 
    private String texto = "Começar";

    public Botao(int posinicialx, int posinicialy, String texto) {
        this.posinicialx = posinicialx;
        this.posinicialy = posinicialy;
        this.texto = texto;
    }
    
    public Botao() {
    }
    
    void imprimir(){
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx, posinicialy);
        Fjalp2.getTerminal().setCor(Corlinha, CorFonte.PRETO);
        Fjalp2.getTerminal().escrevaln(" _________________ ");
        Fjalp2.getTerminal().setCor(Corlinha, Corsombreamento);
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+1, posinicialy);
        Fjalp2.getTerminal().escrevaln("|                 |");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+2, posinicialy);
        
        int tamanhoespacos = 12-texto.length();
        
        for(int i=0; i<tamanhoespacos; i++) texto += " ";
        Fjalp2.getTerminal().escrevaln("|     "+texto+"|");
        
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+3, posinicialy);
        Fjalp2.getTerminal().escrevaln("|_________________|");
        Fjalp2.getTerminal().setPosicaoCursor(posinicialx+4, posinicialy);
        
    }
}
