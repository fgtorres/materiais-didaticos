public interface Tela {
    
    public void imprimircabecalho();
    public void resetCursorPosition();
}
