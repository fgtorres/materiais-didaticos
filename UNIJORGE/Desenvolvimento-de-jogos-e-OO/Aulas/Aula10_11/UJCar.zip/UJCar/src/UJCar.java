
import ujcar.controle.Carro;
import ujcar.controle.Freio;
import ujcar.controle.Motor;
import ujcar.controle.Turbo;


public class UJCar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TelaInicial telainicial = new TelaInicial();
        telainicial.imprimircabecalho();
        telainicial.imprimir(); 
        
    }
    
    public static void movimentaCarro(int pos){
        //Seta pra cima
        if(pos==0){
            
        }
        
        //Seta pra baixo
        if(pos==1){
            
        }
        
        //Seta pra esquerda
        if(pos==2){
            
        }
        
        //Seta pra direita
        if(pos==3){
            
        }
    }
     
    
}
